#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>

using namespace geode::prelude;

class $modify(PlsDoNotClickMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) {
            return false;
        }

        auto menu = CCMenu::create();
        menu->setID("pls-do-not-click-menu");
        menu->setPosition({0.f, 0.f});
        menu->setContentSize(CCDirector::sharedDirector()->getWinSize());
        menu->ignoreAnchorPointForPosition(false);

        auto buttonSprite = ButtonSprite::create("pls do not click");
        auto button = CCMenuItemSpriteExtra::create(
            buttonSprite,
            this,
            menu_selector(PlsDoNotClickMenuLayer::onPlsDoNotClick)
        );

        auto winSize = CCDirector::sharedDirector()->getWinSize();
        button->setPosition({winSize.width - 95.f, 55.f});

        menu->addChild(button);
        this->addChild(menu, 100);

        return true;
    }

    void onPlsDoNotClick(CCObject*) {
        // Intentionally does nothing.
    }
};
