# pls-do-not-click

## Target
- Geometry Dash: 2.2081
- Android
- Geode SDK

## What it does
Adds a clickable button to the Geometry Dash main menu with the text:

`pls do not click`

Clicking it does nothing.

## Build
Install the Geode CLI/SDK and Android NDK first. Then:

```bash
geode sdk install-binaries -p android64
geode build -p android64
```

For a 32-bit Android device, use:

```bash
geode sdk install-binaries -p android32
geode build -p android32
```

The official Geode documentation says Android builds require the Android NDK and the matching Geode Android binaries. The resulting `.geode` package is produced in the corresponding build directory.

Source:
https://docs.geode-sdk.org/getting-started/create-mod/
