# pls do not click

A tiny Geometry Dash 2.2081 Android Geode mod.

It adds a button whose text is:

**pls do not click**

The button is intentionally harmless.
